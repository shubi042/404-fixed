"use strict";(()=>{var e={};e.id=821,e.ids=[821],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},6005:e=>{e.exports=require("node:crypto")},14557:(e,o,t)=>{t.r(o),t.d(o,{originalPathname:()=>f,patchFetch:()=>y,requestAsyncStorage:()=>g,routeModule:()=>m,serverHooks:()=>h,staticGenerationAsyncStorage:()=>u});var r={};t.r(r),t.d(r,{POST:()=>p,dynamic:()=>d,runtime:()=>c});var s=t(73278),n=t(45002),a=t(54877),i=t(71309),l=t(7077);let c="nodejs",d="force-dynamic";async function p(e){try{console.log("\uD83E\uDDEA Testing with real contractor from Google Sheets...");let e=[];if(process.env.GOOGLE_SHEET_ID&&process.env.GOOGLE_CLIENT_EMAIL&&process.env.GOOGLE_PRIVATE_KEY)try{console.log("\uD83D\uDCCA Attempting to read contractors from Google Sheets..."),e=[{name:"Real Contractor 1",email:"contractor1@example.com",phone:"(416) 555-0001",specialties:["airbnb","residential"]},{name:"Real Contractor 2",email:"contractor2@example.com",phone:"(416) 555-0002",specialties:["post-construction"]}],console.log("✅ Found contractors in sheet (simulated)")}catch(e){console.log("⚠️ Using fallback contractors")}0===e.length&&(e=[{name:"Maria Santos",email:"maria@tidymate.ca",phone:"(416) 555-0101",specialties:["airbnb","residential"]},{name:"David Chen",email:"david@tidymate.ca",phone:"(416) 555-0102",specialties:["post-construction"]},{name:"Sarah Johnson",email:"sarah@tidymate.ca",phone:"(416) 555-0103",specialties:["airbnb","residential"]},{name:"Ahmed Hassan",email:"ahmed@tidymate.ca",phone:"(416) 555-0104",specialties:["post-construction"]}]);let o=e.find(e=>e.specialties.includes("airbnb")||e.specialties.includes("residential"))||e[0];console.log(`👷 Selected contractor: ${o.name} (${o.email})`);let t={customerName:"Real Test Customer",customerEmail:"realtest@example.com",phone:"(416) 555-7890",address:"456 Real Test Avenue, Toronto, ON M5V 1A1",serviceName:"Airbnb/Residential 3 Bedrooms",addons:["Window Cleaning"],totalAmountCents:24e3,currency:"cad",date:"2024-01-22",time:"afternoon",sessionId:"cs_live_test_"+Date.now(),instructions:"Real test booking - please call before arrival"};console.log("\uD83D\uDCCB Test booking details:",t),console.log("\uD83D\uDCE7 Sending emails to all parties...");try{let e=await (0,l.bd)(t,{contractorName:o.name,contractorEmail:o.email,contractorPhone:o.phone,estimatedDuration:4});console.log("✅ Business email sent:",e)}catch(e){console.log("❌ Business email error:",e.message)}try{let e=await (0,l.d2)(t,t.customerEmail);console.log("✅ Customer email sent:",e)}catch(e){console.log("❌ Customer email error:",e.message)}try{let e=await (0,l.EA)(o.email,o.name,{service:t.serviceName,addons:"Window Cleaning",estimatedDuration:"4 hours",date:t.date,time:t.time,address:t.address,instructions:t.instructions,customerName:t.customerName,phone:t.phone,customerEmail:t.customerEmail});console.log("✅ Contractor email sent:",e)}catch(e){console.log("❌ Contractor email error:",e.message)}return i.NextResponse.json({success:!0,message:"Real contractor test completed",selectedContractor:o,testBooking:t,emailsSent:{business:"services@tidymate.ca",customer:t.customerEmail,contractor:o.email}})}catch(e){return console.error("❌ Real contractor test error:",e),i.NextResponse.json({error:e.message},{status:500})}}let m=new s.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/test-real-contractor/route",pathname:"/api/test-real-contractor",filename:"route",bundlePath:"app/api/test-real-contractor/route"},resolvedPagePath:"/workspace/fix-404/app/api/test-real-contractor/route.ts",nextConfigOutput:"",userland:r}),{requestAsyncStorage:g,staticGenerationAsyncStorage:u,serverHooks:h}=m,f="/api/test-real-contractor/route";function y(){return(0,a.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:u})}},7077:(e,o,t)=>{t.d(o,{EA:()=>d,bd:()=>i,d2:()=>c,rJ:()=>l});var r=t(54425);let s=process.env.RESEND_API_KEY,n=process.env.OWNER_NOTIFICATION_EMAIL||"services@tidymate.ca",a=process.env.FROM_EMAIL||"noreply@tidymate.ca";async function i(e,o){if(!s)return console.warn("Email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let t=new r.R(s),i=`New Booking: ${e.serviceName} for ${e.customerName}${o?` - Assigned to ${o.contractorName}`:""}`,l=e.addons&&e.addons.length>0?e.addons.join(", "):"None",c=e.totalAmountCents&&e.currency?`${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`:"(total shown in Stripe)",d=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #059669;">💼 New Booking Received - ${o?"Contractor Assigned":"Action Required"}</h2>
			
			${o?`
			<div style="background: #d1fae5; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
				<h3 style="margin-top: 0; color: #065f46;">👷 CONTRACTOR ASSIGNED</h3>
				<p><strong>Assigned to:</strong> ${o.contractorName}</p>
				<p><strong>Contractor Email:</strong> ${o.contractorEmail}</p>
				<p><strong>Contractor Phone:</strong> ${o.contractorPhone}</p>
				<p><strong>Estimated Duration:</strong> ${o.estimatedDuration||"2-3 hours"}</p>
				<p><em>✅ Contractor has been automatically notified via email</em></p>
			</div>
			`:`
			<div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h3>⚠️ MANUAL ASSIGNMENT NEEDED:</h3>
				<p>No contractor was automatically assigned. Please assign manually.</p>
			</div>
			`}
			
			<div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">📋 Booking Details</h3>
				<p><strong>Service:</strong> ${e.serviceName}</p>
				<p><strong>Add-ons:</strong> ${l}</p>
				<p><strong>Total Paid:</strong> ${c}</p>
				<p><strong>Date:</strong> ${e.date}</p>
				<p><strong>Time:</strong> ${e.time}</p>
				${e.sessionId?`<p><strong>Payment Session:</strong> ${e.sessionId}</p>`:""}
			</div>
			
			<div style="background: #fef7cd; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
				<h3 style="margin-top: 0; color: #92400e;">👤 Customer Information</h3>
				<p><strong>Name:</strong> ${e.customerName}</p>
				<p><strong>Email:</strong> ${e.customerEmail}</p>
				<p><strong>Phone:</strong> ${e.phone}</p>
				<p><strong>Address:</strong> ${e.address}</p>
				<p><strong>Special Instructions:</strong> ${e.address}</p>
			</div>
			
			<div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #22c55e;">
				<h3 style="margin-top: 0; color: #15803d;">📋 Your Action Items</h3>
				<ol style="color: #166534;">
					${o?`<li><strong>Contractor notified</strong> - ${o.contractorName} has been emailed</li>
						 <li><strong>Monitor progress</strong> - Follow up with contractor if needed</li>
						 <li><strong>Customer contact</strong> - Confirm final scheduling with customer</li>`:`<li><strong>Assign contractor manually</strong> - No automatic assignment made</li>
						 <li><strong>Contact customer</strong> - Confirm scheduling details</li>
						 <li><strong>Send contractor details</strong> - Once assigned</li>`}
					<li><strong>Quality check</strong> - Ensure service meets TidyMate standards</li>
				</ol>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>📊 Booking tracked in Google Sheets</strong><br/>
				All details automatically recorded for your records
			</p>
		</div>
	`;return await t.emails.send({from:a,to:n,subject:i,html:d}),{success:!0}}async function l(e){if(!s)return console.error("❌ RESEND_API_KEY is not configured"),{skipped:!0,error:"RESEND_API_KEY not configured"};let o=new r.R(s),t=process.env.CONTACT_TO_EMAIL||"services@tidymate.ca",n=`[Contact] ${e.subject||"New message"} — ${e.name}`;console.log("\uD83D\uDCE7 Attempting to send email:",{from:a,to:t,subject:n,hasApiKey:!!s});let i=`
		<h2>New Contact Form Submission</h2>
		<p><strong>Name:</strong> ${e.name}</p>
		<p><strong>Email:</strong> ${e.email}</p>
		<p><strong>Subject:</strong> ${e.subject}</p>
		<p><strong>Message:</strong><br/>${e.message.replace(/\n/g,"<br/>")}</p>
	`;try{let e=await o.emails.send({from:a,to:t,subject:n,html:i});return console.log("✅ Email sent successfully:",e),{success:!0,result:e}}catch(e){throw console.error("❌ Email send failed:",e),Error(`Email send failed: ${e.message}`)}}async function c(e,o){if(!s)return console.warn("Customer email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let t=new r.R(s),n=`Your TidyMate Booking is Confirmed - ${e.serviceName}`,i=e.addons&&e.addons.length>0?e.addons.join(", "):"None",l=e.totalAmountCents&&e.currency?`${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`:"(total shown in receipt)",c=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #2563eb;">🎉 Booking Confirmed - Thank you, ${e.customerName}!</h2>
			<p>Your cleaning service has been booked and payment processed successfully!</p>
			
			<div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">📋 Your Booking Details</h3>
				<p><strong>Service:</strong> ${e.serviceName}</p>
				<p><strong>Add-ons:</strong> ${i}</p>
				<p><strong>Total Paid:</strong> ${l}</p>
				<p><strong>Requested Date:</strong> ${e.date}</p>
				<p><strong>Preferred Time:</strong> ${e.time}</p>
				<p><strong>Service Address:</strong> ${e.address}</p>
				${e.sessionId?`<p><strong>Booking Reference:</strong> ${e.sessionId}</p>`:""}
			</div>
			
			<div style="background: #f0f9ff; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h3 style="color: #1e40af;">📅 What Happens Next:</h3>
				<ol style="color: #374151;">
					<li><strong>We'll contact you within 2 hours</strong> to confirm the exact time slot</li>
					<li><strong>Our professional cleaner will arrive</strong> at your scheduled time</li>
					<li><strong>Enjoy your spotless space!</strong></li>
				</ol>
			</div>
			
			<div style="background: #ecfdf5; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #10b981;">
				<h4 style="margin-top: 0; color: #065f46;">🔒 Payment Confirmation</h4>
				<p style="color: #047857;">✅ Your payment has been securely processed</p>
				<p style="color: #047857;">✅ Booking is confirmed and scheduled</p>
			</div>
			
			<div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h4 style="margin-top: 0; color: #92400e;">📞 Important Reminders</h4>
				<ul style="color: #78350f;">
					<li><strong>Cancellation Policy:</strong> No refunds after booking. Cancellations within 24 hours result in payment forfeiture.</li>
					<li><strong>Access:</strong> Please ensure someone is available to provide access to the property</li>
					<li><strong>Contact:</strong> Call or email us immediately if you need to make changes</li>
				</ul>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>Questions or concerns?</strong><br/>
				Email: <a href="mailto:services@tidymate.ca" style="color: #2563eb;">services@tidymate.ca</a><br/>
				We're here to help ensure your cleaning experience is perfect!
			</p>
		</div>
	`;return await t.emails.send({from:a,to:o,subject:n,html:c}),{success:!0}}async function d(e,o,t){if(!s)return console.warn("Contractor email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let n=new r.R(s),i=`New Job Assignment - ${t.service} on ${t.date}`,l=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #dc2626;">🔧 New Job Assignment - ${o}</h2>
			<p>You have been assigned a new cleaning job. Please review the details below:</p>
			
			<div style="background: #fee2e2; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #dc2626;">
				<h3 style="margin-top: 0; color: #991b1b;">📋 Job Details</h3>
				<p><strong>Service:</strong> ${t.service}</p>
				<p><strong>Add-ons:</strong> ${t.addons||"None"}</p>
				<p><strong>Estimated Duration:</strong> ${t.estimatedDuration||"2-3 hours"}</p>
				<p><strong>Date:</strong> ${t.date}</p>
				<p><strong>Time:</strong> ${t.time}</p>
			</div>
			
			<div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
				<h3 style="margin-top: 0; color: #92400e;">📍 Location & Access</h3>
				<p><strong>Address:</strong> ${t.address}</p>
				<p><strong>Special Instructions:</strong> ${t.instructions||"None provided"}</p>
			</div>
			
			<div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">👤 Customer Information</h3>
				<p><strong>Customer:</strong> ${t.customerName}</p>
				<p><strong>Phone:</strong> ${t.phone}</p>
				<p><strong>Email:</strong> ${t.customerEmail}</p>
			</div>
			
			<div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #22c55e;">
				<h3 style="margin-top: 0; color: #15803d;">✅ Action Required</h3>
				<ol style="color: #166534;">
					<li><strong>Contact customer</strong> to confirm exact arrival time</li>
					<li><strong>Arrive punctually</strong> with all necessary equipment</li>
					<li><strong>Complete service</strong> according to TidyMate standards</li>
					<li><strong>Send completion confirmation</strong> to services@tidymate.ca</li>
				</ol>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>Questions about this assignment?</strong><br/>
				Contact: <a href="mailto:services@tidymate.ca" style="color: #2563eb;">services@tidymate.ca</a><br/>
				<strong>Payment:</strong> You'll be paid according to your contractor agreement
			</p>
		</div>
	`;return await n.emails.send({from:a,to:e,subject:i,html:l}),{success:!0}}}};var o=require("../../../webpack-runtime.js");o.C(e);var t=e=>o(o.s=e),r=o.X(0,[379,833,425],()=>t(14557));module.exports=r})();