"use strict";(()=>{var e={};e.id=45,e.ids=[45],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},6005:e=>{e.exports=require("node:crypto")},27052:(e,t,o)=>{o.r(t),o.d(t,{originalPathname:()=>f,patchFetch:()=>k,requestAsyncStorage:()=>g,routeModule:()=>y,serverHooks:()=>x,staticGenerationAsyncStorage:()=>h});var r={};o.r(r),o.d(r,{POST:()=>m,dynamic:()=>u,runtime:()=>c});var n=o(73278),s=o(45002),i=o(54877),a=o(71309),l=o(54425);let d=process.env.RESEND_API_KEY,p=process.env.FROM_EMAIL||"noreply@tidymate.ca",c="nodejs",u="force-dynamic";async function m(e){try{let{customerEmail:t,customerName:o,serviceName:r,bookingDate:n,bookingTime:s}=await e.json();if(!t||!o)return a.NextResponse.json({error:"Customer email and name required"},{status:400});if(!d)return a.NextResponse.json({error:"Email service not configured"},{status:500});let i=new l.R(d),c=`📅 Choose Your Cleaning Time Slot - ${r||"TidyMate Service"}`,u=`
			<h2>Hi ${o}! 👋</h2>
			<p>Thank you for your booking! Now it's time to choose your exact time slot.</p>
			
			<div style="background: #f0f9ff; padding: 20px; border-radius: 10px; margin: 20px 0; text-align: center;">
				<h3>🗓️ Click Below to Choose Your Time</h3>
				<p style="margin: 15px 0;">Select the exact time that works best for you:</p>
				<a href="https://calendly.com/services-tidymate/booking-confirmation" 
				   style="background: #0066cc; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
					📅 BOOK YOUR TIME SLOT
				</a>
			</div>
			
			<h3>Your Booking Details:</h3>
			<ul>
				<li><strong>Service:</strong> ${r||"Professional Cleaning"}</li>
				<li><strong>Requested Date:</strong> ${n||"As discussed"}</li>
				<li><strong>Requested Time:</strong> ${s||"As discussed"}</li>
			</ul>
			
			<p><strong>What happens next:</strong></p>
			<ol>
				<li>Click the button above to access our calendar</li>
				<li>Choose your preferred time slot</li>
				<li>Receive final confirmation from our team</li>
				<li>Enjoy your professional cleaning service!</li>
			</ol>
			
			<div style="background: #e6f7e6; padding: 15px; border-radius: 8px; margin-top: 20px;">
				<p><strong>✅ Your payment is already confirmed!</strong></p>
				<p>This is just to select your preferred time slot.</p>
			</div>
			
			<p style="margin-top: 20px;"><em>Questions? Reply to this email or contact us at services@tidymate.ca</em></p>
		`;return await i.emails.send({from:p,to:t,subject:c,html:u}),a.NextResponse.json({success:!0,message:"Calendly link sent successfully"})}catch(e){return console.error("Send Calendly link error:",e),a.NextResponse.json({error:e?.message||"Failed to send Calendly link"},{status:500})}}let y=new n.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/send-calendly-link/route",pathname:"/api/send-calendly-link",filename:"route",bundlePath:"app/api/send-calendly-link/route"},resolvedPagePath:"/workspace/fix-404/app/api/send-calendly-link/route.ts",nextConfigOutput:"",userland:r}),{requestAsyncStorage:g,staticGenerationAsyncStorage:h,serverHooks:x}=y,f="/api/send-calendly-link/route";function k(){return(0,i.patchFetch)({serverHooks:x,staticGenerationAsyncStorage:h})}}};var t=require("../../../webpack-runtime.js");t.C(e);var o=e=>t(t.s=e),r=t.X(0,[379,833,425],()=>o(27052));module.exports=r})();