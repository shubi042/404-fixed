"use strict";(()=>{var e={};e.id=234,e.ids=[234],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},21764:e=>{e.exports=require("util")},6005:e=>{e.exports=require("node:crypto")},57068:(e,o,r)=>{r.r(o),r.d(o,{originalPathname:()=>b,patchFetch:()=>x,requestAsyncStorage:()=>f,routeModule:()=>u,serverHooks:()=>h,staticGenerationAsyncStorage:()=>y});var t={};r.r(t),r.d(t,{POST:()=>m,dynamic:()=>p,runtime:()=>c});var s=r(73278),n=r(45002),i=r(54877),a=r(71309),d=r(3854),l=r(7077);let c="nodejs",p="force-dynamic";async function g(e,o){try{await fetch(`${e}/.netlify/functions/send-email`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:"booking",...o})})}catch(e){console.error("SMTP fallback send failed:",e)}}async function m(e){try{let o=process.env.STRIPE_SECRET_KEY;if(!o)return a.NextResponse.json({error:"Stripe secret key not configured"},{status:500});let r=new d.Z(o,{apiVersion:"2024-06-20"}),t=null,{searchParams:s}=new URL(e.url);if(!(t=s.get("session_id")))try{let o=await e.json();t=o?.sessionId||o?.session_id||null}catch(e){}if(!t)return a.NextResponse.json({error:"Session ID required"},{status:400});let n=await r.checkout.sessions.retrieve(t,{expand:["line_items","customer"]});if("paid"!==n.payment_status)return a.NextResponse.json({skipped:!0,reason:"Session not paid"},{status:200});let i=n.metadata||{},c=(i.addons?String(i.addons):"").split(",").map(e=>e.trim()).filter(Boolean),p={customerName:String(i.customerName||"Unknown"),customerEmail:String(n.customer_email||i.customerEmail||"unknown@example.com"),phone:String(i.phone||""),address:String(i.address||""),date:String(i.date||""),time:String(i.time||""),serviceName:String(i.service||n?.line_items?.data?.[0]?.description||"Cleaning Service"),addons:c,totalAmountCents:"number"==typeof n.amount_total?n.amount_total:void 0,currency:n.currency||void 0,sessionId:n.id};await (0,l.bd)(p);let m=e.headers.get("origin")||new URL(e.url).origin;return g(m,p),a.NextResponse.json({ok:!0})}catch(e){return console.error("Notify owner error:",e),a.NextResponse.json({error:e?.message||"Failed to notify owner"},{status:500})}}let u=new s.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/notify-owner/route",pathname:"/api/notify-owner",filename:"route",bundlePath:"app/api/notify-owner/route"},resolvedPagePath:"/workspace/fix-404/app/api/notify-owner/route.ts",nextConfigOutput:"",userland:t}),{requestAsyncStorage:f,staticGenerationAsyncStorage:y,serverHooks:h}=u,b="/api/notify-owner/route";function x(){return(0,i.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:y})}},7077:(e,o,r)=>{r.d(o,{EA:()=>c,bd:()=>a,d2:()=>l,rJ:()=>d});var t=r(54425);let s=process.env.RESEND_API_KEY,n=process.env.OWNER_NOTIFICATION_EMAIL||"services@tidymate.ca",i=process.env.FROM_EMAIL||"noreply@tidymate.ca";async function a(e,o){if(!s)return console.warn("Email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let r=new t.R(s),a=`New Booking: ${e.serviceName} for ${e.customerName}${o?` - Assigned to ${o.contractorName}`:""}`,d=e.addons&&e.addons.length>0?e.addons.join(", "):"None",l=e.totalAmountCents&&e.currency?`${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`:"(total shown in Stripe)",c=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #059669;">💼 New Booking Received - ${o?"Contractor Assigned":"Action Required"}</h2>
			
			${o?`
			<div style="background: #d1fae5; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
				<h3 style="margin-top: 0; color: #065f46;">👷 CONTRACTOR ASSIGNED</h3>
				<p><strong>Assigned to:</strong> ${o.contractorName}</p>
				<p><strong>Contractor Email:</strong> ${o.contractorEmail}</p>
				<p><strong>Contractor Phone:</strong> ${o.contractorPhone}</p>
				<p><strong>Estimated Duration:</strong> ${o.estimatedDuration||"2-3 hours"}</p>
				<p><em>✅ Contractor has been automatically notified via email</em></p>
			</div>
			`:`
			<div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h3>⚠️ MANUAL ASSIGNMENT NEEDED:</h3>
				<p>No contractor was automatically assigned. Please assign manually.</p>
			</div>
			`}
			
			<div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">📋 Booking Details</h3>
				<p><strong>Service:</strong> ${e.serviceName}</p>
				<p><strong>Add-ons:</strong> ${d}</p>
				<p><strong>Total Paid:</strong> ${l}</p>
				<p><strong>Date:</strong> ${e.date}</p>
				<p><strong>Time:</strong> ${e.time}</p>
				${e.sessionId?`<p><strong>Payment Session:</strong> ${e.sessionId}</p>`:""}
			</div>
			
			<div style="background: #fef7cd; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
				<h3 style="margin-top: 0; color: #92400e;">👤 Customer Information</h3>
				<p><strong>Name:</strong> ${e.customerName}</p>
				<p><strong>Email:</strong> ${e.customerEmail}</p>
				<p><strong>Phone:</strong> ${e.phone}</p>
				<p><strong>Address:</strong> ${e.address}</p>
				<p><strong>Special Instructions:</strong> ${e.address}</p>
			</div>
			
			<div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #22c55e;">
				<h3 style="margin-top: 0; color: #15803d;">📋 Your Action Items</h3>
				<ol style="color: #166534;">
					${o?`<li><strong>Contractor notified</strong> - ${o.contractorName} has been emailed</li>
						 <li><strong>Monitor progress</strong> - Follow up with contractor if needed</li>
						 <li><strong>Customer contact</strong> - Confirm final scheduling with customer</li>`:`<li><strong>Assign contractor manually</strong> - No automatic assignment made</li>
						 <li><strong>Contact customer</strong> - Confirm scheduling details</li>
						 <li><strong>Send contractor details</strong> - Once assigned</li>`}
					<li><strong>Quality check</strong> - Ensure service meets TidyMate standards</li>
				</ol>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>📊 Booking tracked in Google Sheets</strong><br/>
				All details automatically recorded for your records
			</p>
		</div>
	`;return await r.emails.send({from:i,to:n,subject:a,html:c}),{success:!0}}async function d(e){if(!s)return console.error("❌ RESEND_API_KEY is not configured"),{skipped:!0,error:"RESEND_API_KEY not configured"};let o=new t.R(s),r=process.env.CONTACT_TO_EMAIL||"services@tidymate.ca",n=`[Contact] ${e.subject||"New message"} — ${e.name}`;console.log("\uD83D\uDCE7 Attempting to send email:",{from:i,to:r,subject:n,hasApiKey:!!s});let a=`
		<h2>New Contact Form Submission</h2>
		<p><strong>Name:</strong> ${e.name}</p>
		<p><strong>Email:</strong> ${e.email}</p>
		<p><strong>Subject:</strong> ${e.subject}</p>
		<p><strong>Message:</strong><br/>${e.message.replace(/\n/g,"<br/>")}</p>
	`;try{let e=await o.emails.send({from:i,to:r,subject:n,html:a});return console.log("✅ Email sent successfully:",e),{success:!0,result:e}}catch(e){throw console.error("❌ Email send failed:",e),Error(`Email send failed: ${e.message}`)}}async function l(e,o){if(!s)return console.warn("Customer email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let r=new t.R(s),n=`Your TidyMate Booking is Confirmed - ${e.serviceName}`,a=e.addons&&e.addons.length>0?e.addons.join(", "):"None",d=e.totalAmountCents&&e.currency?`${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`:"(total shown in receipt)",l=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #2563eb;">🎉 Booking Confirmed - Thank you, ${e.customerName}!</h2>
			<p>Your cleaning service has been booked and payment processed successfully!</p>
			
			<div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">📋 Your Booking Details</h3>
				<p><strong>Service:</strong> ${e.serviceName}</p>
				<p><strong>Add-ons:</strong> ${a}</p>
				<p><strong>Total Paid:</strong> ${d}</p>
				<p><strong>Requested Date:</strong> ${e.date}</p>
				<p><strong>Preferred Time:</strong> ${e.time}</p>
				<p><strong>Service Address:</strong> ${e.address}</p>
				${e.sessionId?`<p><strong>Booking Reference:</strong> ${e.sessionId}</p>`:""}
			</div>
			
			<div style="background: #f0f9ff; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h3 style="color: #1e40af;">📅 What Happens Next:</h3>
				<ol style="color: #374151;">
					<li><strong>We'll contact you within 2 hours</strong> to confirm the exact time slot</li>
					<li><strong>Our professional cleaner will arrive</strong> at your scheduled time</li>
					<li><strong>Enjoy your spotless space!</strong></li>
				</ol>
			</div>
			
			<div style="background: #ecfdf5; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #10b981;">
				<h4 style="margin-top: 0; color: #065f46;">🔒 Payment Confirmation</h4>
				<p style="color: #047857;">✅ Your payment has been securely processed</p>
				<p style="color: #047857;">✅ Booking is confirmed and scheduled</p>
			</div>
			
			<div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h4 style="margin-top: 0; color: #92400e;">📞 Important Reminders</h4>
				<ul style="color: #78350f;">
					<li><strong>Cancellation Policy:</strong> No refunds after booking. Cancellations within 24 hours result in payment forfeiture.</li>
					<li><strong>Access:</strong> Please ensure someone is available to provide access to the property</li>
					<li><strong>Contact:</strong> Call or email us immediately if you need to make changes</li>
				</ul>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>Questions or concerns?</strong><br/>
				Email: <a href="mailto:services@tidymate.ca" style="color: #2563eb;">services@tidymate.ca</a><br/>
				We're here to help ensure your cleaning experience is perfect!
			</p>
		</div>
	`;return await r.emails.send({from:i,to:o,subject:n,html:l}),{success:!0}}async function c(e,o,r){if(!s)return console.warn("Contractor email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let n=new t.R(s),a=`New Job Assignment - ${r.service} on ${r.date}`,d=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #dc2626;">🔧 New Job Assignment - ${o}</h2>
			<p>You have been assigned a new cleaning job. Please review the details below:</p>
			
			<div style="background: #fee2e2; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #dc2626;">
				<h3 style="margin-top: 0; color: #991b1b;">📋 Job Details</h3>
				<p><strong>Service:</strong> ${r.service}</p>
				<p><strong>Add-ons:</strong> ${r.addons||"None"}</p>
				<p><strong>Estimated Duration:</strong> ${r.estimatedDuration||"2-3 hours"}</p>
				<p><strong>Date:</strong> ${r.date}</p>
				<p><strong>Time:</strong> ${r.time}</p>
			</div>
			
			<div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
				<h3 style="margin-top: 0; color: #92400e;">📍 Location & Access</h3>
				<p><strong>Address:</strong> ${r.address}</p>
				<p><strong>Special Instructions:</strong> ${r.instructions||"None provided"}</p>
			</div>
			
			<div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">👤 Customer Information</h3>
				<p><strong>Customer:</strong> ${r.customerName}</p>
				<p><strong>Phone:</strong> ${r.phone}</p>
				<p><strong>Email:</strong> ${r.customerEmail}</p>
			</div>
			
			<div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #22c55e;">
				<h3 style="margin-top: 0; color: #15803d;">✅ Action Required</h3>
				<ol style="color: #166534;">
					<li><strong>Contact customer</strong> to confirm exact arrival time</li>
					<li><strong>Arrive punctually</strong> with all necessary equipment</li>
					<li><strong>Complete service</strong> according to TidyMate standards</li>
					<li><strong>Send completion confirmation</strong> to services@tidymate.ca</li>
				</ol>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>Questions about this assignment?</strong><br/>
				Contact: <a href="mailto:services@tidymate.ca" style="color: #2563eb;">services@tidymate.ca</a><br/>
				<strong>Payment:</strong> You'll be paid according to your contractor agreement
			</p>
		</div>
	`;return await n.emails.send({from:i,to:e,subject:a,html:d}),{success:!0}}}};var o=require("../../../webpack-runtime.js");o.C(e);var r=e=>o(o.s=e),t=o.X(0,[379,833,425,854],()=>r(57068));module.exports=t})();