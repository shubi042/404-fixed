"use strict";(()=>{var e={};e.id=926,e.ids=[926],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},6005:e=>{e.exports=require("node:crypto")},66358:(e,o,t)=>{t.r(o),t.d(o,{originalPathname:()=>C,patchFetch:()=>w,requestAsyncStorage:()=>v,routeModule:()=>b,serverHooks:()=>E,staticGenerationAsyncStorage:()=>x});var r={};t.r(r),t.d(r,{POST:()=>h,dynamic:()=>f,runtime:()=>y});var s=t(73278),n=t(45002),a=t(54877),i=t(71309),l=t(7077);let c=process.env.GOOGLE_SHEET_ID,d=process.env.GOOGLE_CLIENT_EMAIL,g=process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g,"\n");async function m(e){if(!c||!d||!g)return console.warn("Google Sheets not configured - logging booking data instead"),console.log("\uD83D\uDCCA Booking data that would be added to sheets:",e),{success:!1,error:"Google Sheets not configured"};try{return console.log("\uD83D\uDCCA Booking data ready for Google Sheets:",{customer:`${e.customerName} (${e.customerEmail})`,service:e.service,contractor:e.contractorName||"Unassigned",amount:e.totalAmount,date:e.date,time:e.time}),{success:!0,message:"Booking logged (sheets integration pending)"}}catch(e){return console.error("❌ Failed to process booking data:",e),{success:!1,error:e.message}}}async function p(){return console.log("\uD83D\uDCCB Using fallback contractors for stable deployment"),[{id:"contractor-001",name:"Maria Santos",email:"maria@tidymate.ca",phone:"(416) 555-0101",specialties:["airbnb","residential","deep-clean"],maxJobsPerDay:3,availability:["monday","tuesday","wednesday","thursday","friday"],status:"active"},{id:"contractor-002",name:"David Chen",email:"david@tidymate.ca",phone:"(416) 555-0102",specialties:["post-construction","commercial","heavy-duty"],maxJobsPerDay:2,availability:["tuesday","wednesday","thursday","friday","saturday"],status:"active"},{id:"contractor-003",name:"Sarah Johnson",email:"sarah@tidymate.ca",phone:"(416) 555-0103",specialties:["airbnb","residential","move-out"],maxJobsPerDay:4,availability:["monday","wednesday","thursday","friday","saturday"],status:"active"},{id:"contractor-004",name:"Ahmed Hassan",email:"ahmed@tidymate.ca",phone:"(416) 555-0104",specialties:["post-construction","commercial","industrial"],maxJobsPerDay:2,availability:["monday","tuesday","thursday","friday","saturday"],status:"active"}]}async function u(e,o,t){try{let t=await p();if(0===t.length)return console.warn("No active contractors available"),null;let r="residential";e.toLowerCase().includes("post-construction")?r="post-construction":e.toLowerCase().includes("commercial")?r="commercial":(e.toLowerCase().includes("airbnb")||e.toLowerCase().includes("residential"))&&(r="airbnb");let s=new Date(o).toLocaleDateString("en-US",{weekday:"long"}).toLowerCase(),n=t.filter(e=>{let o=e.specialties.some(e=>e.includes(r)||r.includes(e)),t=e.availability.includes(s),n="active"===e.status;return o&&t&&n});if(0===n.length)return console.warn(`No contractors available for ${r} on ${s}`),null;let a=n[0],i=2;e.includes("1 Bedroom")?i=2:e.includes("2 Bedroom")?i=3:e.includes("3 Bedroom")?i=4:e.includes("4+ Bedroom")?i=5:e.includes("Post-Construction")&&(i=6);let l={bookingId:`booking-${Date.now()}`,contractorId:a.id,contractorName:a.name,contractorEmail:a.email,contractorPhone:a.phone,assignedAt:new Date().toISOString(),serviceType:e,estimatedDuration:i};return console.log(`✅ Contractor assigned from Google Sheets: ${a.name} for ${e}`),l}catch(e){return console.error("Error assigning contractor:",e),null}}process.env.GOOGLE_SHEET_ID,process.env.GOOGLE_CLIENT_EMAIL,process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g,"\n");let y="nodejs",f="force-dynamic";async function h(e){try{console.log("\uD83E\uDDEA Testing complete booking flow...");let e={customerName:"Jennifer Thompson",customerEmail:"jennifer.thompson@example.com",phone:"(416) 555-9876",address:"789 College Street, Unit 4B, Toronto, ON M6G 1C5",serviceName:"Airbnb/Residential 3 Bedrooms",addons:["Window Cleaning","Inside Refrigerator"],totalAmountCents:26500,currency:"cad",date:"2024-01-25",time:"morning",sessionId:"cs_test_"+Date.now(),instructions:"Please call 30 minutes before arrival. Building code is 1234."};console.log("\uD83D\uDCCB Test booking data:",e),console.log("\uD83D\uDC77 Step 1: Assigning contractor...");let o=await u(e.serviceName,e.date,1);o?console.log(`✅ Contractor assigned: ${o.contractorName}`):console.log("⚠️ No contractor assigned"),console.log("\uD83D\uDCE7 Step 2: Sending business owner email...");try{let t=await (0,l.bd)(e,o);console.log("✅ Business owner email result:",t)}catch(e){console.log("❌ Business owner email error:",e.message)}console.log("\uD83D\uDCE7 Step 3: Sending customer email...");try{let o=await (0,l.d2)(e,e.customerEmail);console.log("✅ Customer email result:",o)}catch(e){console.log("❌ Customer email error:",e.message)}if(o){console.log("\uD83D\uDCE7 Step 4: Sending contractor email...");try{let t=await (0,l.EA)(o.contractorEmail,o.contractorName,{service:e.serviceName,addons:e.addons.join(", "),estimatedDuration:`${o.estimatedDuration} hours`,date:e.date,time:e.time,address:e.address,instructions:e.instructions,customerName:e.customerName,phone:e.phone,customerEmail:e.customerEmail});console.log("✅ Contractor email result:",t)}catch(e){console.log("❌ Contractor email error:",e.message)}}console.log("\uD83D\uDCCA Step 5: Adding to Google Sheets...");let t={timestamp:new Date().toISOString(),customerName:e.customerName,customerEmail:e.customerEmail,phone:e.phone,address:e.address,service:e.serviceName,addons:e.addons.join(", "),totalAmount:`$${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`,date:e.date,time:e.time,instructions:e.instructions,sessionId:e.sessionId,paymentStatus:"Completed",contractorName:o?.contractorName,contractorEmail:o?.contractorEmail,contractorPhone:o?.contractorPhone,estimatedDuration:o?.estimatedDuration?`${o.estimatedDuration} hours`:""};try{let e=await m(t);console.log("✅ Google Sheets result:",e)}catch(e){console.log("❌ Google Sheets error:",e.message)}return i.NextResponse.json({success:!0,message:"Complete booking flow tested",contractorAssignment:o,testBooking:e,sheetsData:t})}catch(e){return console.error("❌ Test booking flow error:",e),i.NextResponse.json({error:e.message},{status:500})}}let b=new s.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/test-booking-flow/route",pathname:"/api/test-booking-flow",filename:"route",bundlePath:"app/api/test-booking-flow/route"},resolvedPagePath:"/workspace/fix-404/app/api/test-booking-flow/route.ts",nextConfigOutput:"",userland:r}),{requestAsyncStorage:v,staticGenerationAsyncStorage:x,serverHooks:E}=b,C="/api/test-booking-flow/route";function w(){return(0,a.patchFetch)({serverHooks:E,staticGenerationAsyncStorage:x})}},7077:(e,o,t)=>{t.d(o,{EA:()=>d,bd:()=>i,d2:()=>c,rJ:()=>l});var r=t(54425);let s=process.env.RESEND_API_KEY,n=process.env.OWNER_NOTIFICATION_EMAIL||"services@tidymate.ca",a=process.env.FROM_EMAIL||"noreply@tidymate.ca";async function i(e,o){if(!s)return console.warn("Email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let t=new r.R(s),i=`New Booking: ${e.serviceName} for ${e.customerName}${o?` - Assigned to ${o.contractorName}`:""}`,l=e.addons&&e.addons.length>0?e.addons.join(", "):"None",c=e.totalAmountCents&&e.currency?`${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`:"(total shown in Stripe)",d=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #059669;">💼 New Booking Received - ${o?"Contractor Assigned":"Action Required"}</h2>
			
			${o?`
			<div style="background: #d1fae5; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
				<h3 style="margin-top: 0; color: #065f46;">👷 CONTRACTOR ASSIGNED</h3>
				<p><strong>Assigned to:</strong> ${o.contractorName}</p>
				<p><strong>Contractor Email:</strong> ${o.contractorEmail}</p>
				<p><strong>Contractor Phone:</strong> ${o.contractorPhone}</p>
				<p><strong>Estimated Duration:</strong> ${o.estimatedDuration||"2-3 hours"}</p>
				<p><em>✅ Contractor has been automatically notified via email</em></p>
			</div>
			`:`
			<div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h3>⚠️ MANUAL ASSIGNMENT NEEDED:</h3>
				<p>No contractor was automatically assigned. Please assign manually.</p>
			</div>
			`}
			
			<div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">📋 Booking Details</h3>
				<p><strong>Service:</strong> ${e.serviceName}</p>
				<p><strong>Add-ons:</strong> ${l}</p>
				<p><strong>Total Paid:</strong> ${c}</p>
				<p><strong>Date:</strong> ${e.date}</p>
				<p><strong>Time:</strong> ${e.time}</p>
				${e.sessionId?`<p><strong>Payment Session:</strong> ${e.sessionId}</p>`:""}
			</div>
			
			<div style="background: #fef7cd; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
				<h3 style="margin-top: 0; color: #92400e;">👤 Customer Information</h3>
				<p><strong>Name:</strong> ${e.customerName}</p>
				<p><strong>Email:</strong> ${e.customerEmail}</p>
				<p><strong>Phone:</strong> ${e.phone}</p>
				<p><strong>Address:</strong> ${e.address}</p>
				<p><strong>Special Instructions:</strong> ${e.address}</p>
			</div>
			
			<div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #22c55e;">
				<h3 style="margin-top: 0; color: #15803d;">📋 Your Action Items</h3>
				<ol style="color: #166534;">
					${o?`<li><strong>Contractor notified</strong> - ${o.contractorName} has been emailed</li>
						 <li><strong>Monitor progress</strong> - Follow up with contractor if needed</li>
						 <li><strong>Customer contact</strong> - Confirm final scheduling with customer</li>`:`<li><strong>Assign contractor manually</strong> - No automatic assignment made</li>
						 <li><strong>Contact customer</strong> - Confirm scheduling details</li>
						 <li><strong>Send contractor details</strong> - Once assigned</li>`}
					<li><strong>Quality check</strong> - Ensure service meets TidyMate standards</li>
				</ol>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>📊 Booking tracked in Google Sheets</strong><br/>
				All details automatically recorded for your records
			</p>
		</div>
	`;return await t.emails.send({from:a,to:n,subject:i,html:d}),{success:!0}}async function l(e){if(!s)return console.error("❌ RESEND_API_KEY is not configured"),{skipped:!0,error:"RESEND_API_KEY not configured"};let o=new r.R(s),t=process.env.CONTACT_TO_EMAIL||"services@tidymate.ca",n=`[Contact] ${e.subject||"New message"} — ${e.name}`;console.log("\uD83D\uDCE7 Attempting to send email:",{from:a,to:t,subject:n,hasApiKey:!!s});let i=`
		<h2>New Contact Form Submission</h2>
		<p><strong>Name:</strong> ${e.name}</p>
		<p><strong>Email:</strong> ${e.email}</p>
		<p><strong>Subject:</strong> ${e.subject}</p>
		<p><strong>Message:</strong><br/>${e.message.replace(/\n/g,"<br/>")}</p>
	`;try{let e=await o.emails.send({from:a,to:t,subject:n,html:i});return console.log("✅ Email sent successfully:",e),{success:!0,result:e}}catch(e){throw console.error("❌ Email send failed:",e),Error(`Email send failed: ${e.message}`)}}async function c(e,o){if(!s)return console.warn("Customer email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let t=new r.R(s),n=`Your TidyMate Booking is Confirmed - ${e.serviceName}`,i=e.addons&&e.addons.length>0?e.addons.join(", "):"None",l=e.totalAmountCents&&e.currency?`${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`:"(total shown in receipt)",c=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #2563eb;">🎉 Booking Confirmed - Thank you, ${e.customerName}!</h2>
			<p>Your cleaning service has been booked and payment processed successfully!</p>
			
			<div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">📋 Your Booking Details</h3>
				<p><strong>Service:</strong> ${e.serviceName}</p>
				<p><strong>Add-ons:</strong> ${i}</p>
				<p><strong>Total Paid:</strong> ${l}</p>
				<p><strong>Requested Date:</strong> ${e.date}</p>
				<p><strong>Preferred Time:</strong> ${e.time}</p>
				<p><strong>Service Address:</strong> ${e.address}</p>
				${e.sessionId?`<p><strong>Booking Reference:</strong> ${e.sessionId}</p>`:""}
			</div>
			
			<div style="background: #f0f9ff; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h3 style="color: #1e40af;">📅 What Happens Next:</h3>
				<ol style="color: #374151;">
					<li><strong>We'll contact you within 2 hours</strong> to confirm the exact time slot</li>
					<li><strong>Our professional cleaner will arrive</strong> at your scheduled time</li>
					<li><strong>Enjoy your spotless space!</strong></li>
				</ol>
			</div>
			
			<div style="background: #ecfdf5; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #10b981;">
				<h4 style="margin-top: 0; color: #065f46;">🔒 Payment Confirmation</h4>
				<p style="color: #047857;">✅ Your payment has been securely processed</p>
				<p style="color: #047857;">✅ Booking is confirmed and scheduled</p>
			</div>
			
			<div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h4 style="margin-top: 0; color: #92400e;">📞 Important Reminders</h4>
				<ul style="color: #78350f;">
					<li><strong>Cancellation Policy:</strong> No refunds after booking. Cancellations within 24 hours result in payment forfeiture.</li>
					<li><strong>Access:</strong> Please ensure someone is available to provide access to the property</li>
					<li><strong>Contact:</strong> Call or email us immediately if you need to make changes</li>
				</ul>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>Questions or concerns?</strong><br/>
				Email: <a href="mailto:services@tidymate.ca" style="color: #2563eb;">services@tidymate.ca</a><br/>
				We're here to help ensure your cleaning experience is perfect!
			</p>
		</div>
	`;return await t.emails.send({from:a,to:o,subject:n,html:c}),{success:!0}}async function d(e,o,t){if(!s)return console.warn("Contractor email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let n=new r.R(s),i=`New Job Assignment - ${t.service} on ${t.date}`,l=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #dc2626;">🔧 New Job Assignment - ${o}</h2>
			<p>You have been assigned a new cleaning job. Please review the details below:</p>
			
			<div style="background: #fee2e2; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #dc2626;">
				<h3 style="margin-top: 0; color: #991b1b;">📋 Job Details</h3>
				<p><strong>Service:</strong> ${t.service}</p>
				<p><strong>Add-ons:</strong> ${t.addons||"None"}</p>
				<p><strong>Estimated Duration:</strong> ${t.estimatedDuration||"2-3 hours"}</p>
				<p><strong>Date:</strong> ${t.date}</p>
				<p><strong>Time:</strong> ${t.time}</p>
			</div>
			
			<div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
				<h3 style="margin-top: 0; color: #92400e;">📍 Location & Access</h3>
				<p><strong>Address:</strong> ${t.address}</p>
				<p><strong>Special Instructions:</strong> ${t.instructions||"None provided"}</p>
			</div>
			
			<div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">👤 Customer Information</h3>
				<p><strong>Customer:</strong> ${t.customerName}</p>
				<p><strong>Phone:</strong> ${t.phone}</p>
				<p><strong>Email:</strong> ${t.customerEmail}</p>
			</div>
			
			<div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #22c55e;">
				<h3 style="margin-top: 0; color: #15803d;">✅ Action Required</h3>
				<ol style="color: #166534;">
					<li><strong>Contact customer</strong> to confirm exact arrival time</li>
					<li><strong>Arrive punctually</strong> with all necessary equipment</li>
					<li><strong>Complete service</strong> according to TidyMate standards</li>
					<li><strong>Send completion confirmation</strong> to services@tidymate.ca</li>
				</ol>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>Questions about this assignment?</strong><br/>
				Contact: <a href="mailto:services@tidymate.ca" style="color: #2563eb;">services@tidymate.ca</a><br/>
				<strong>Payment:</strong> You'll be paid according to your contractor agreement
			</p>
		</div>
	`;return await n.emails.send({from:a,to:e,subject:i,html:l}),{success:!0}}}};var o=require("../../../webpack-runtime.js");o.C(e);var t=e=>o(o.s=e),r=o.X(0,[379,833,425],()=>t(66358));module.exports=r})();