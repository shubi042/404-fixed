"use strict";(()=>{var e={};e.id=757,e.ids=[757],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},21764:e=>{e.exports=require("util")},6005:e=>{e.exports=require("node:crypto")},98922:(e,o,t)=>{t.r(o),t.d(o,{originalPathname:()=>b,patchFetch:()=>v,requestAsyncStorage:()=>h,routeModule:()=>u,serverHooks:()=>y,staticGenerationAsyncStorage:()=>f});var r={};t.r(r),t.d(r,{POST:()=>g,dynamic:()=>p,runtime:()=>l});var s=t(73278),n=t(45002),i=t(54877),a=t(71309),d=t(3854),c=t(7077);let l="nodejs",p="force-dynamic";async function m(e){try{let o=process.env.PUBLIC_BASE_URL;if(!o)return;await fetch(`${o}/.netlify/functions/send-email`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:"booking",...e})})}catch(e){console.error("SMTP fallback send failed:",e)}}async function g(e){let o;let t=process.env.STRIPE_SECRET_KEY,r=process.env.STRIPE_WEBHOOK_SECRET;if(!t||!r)return console.error("Missing STRIPE_SECRET_KEY or STRIPE_WEBHOOK_SECRET"),a.NextResponse.json({received:!0},{status:200});let s=new d.Z(t,{apiVersion:"2024-06-20"}),n=await e.text(),i=e.headers.get("stripe-signature");if(!i)return a.NextResponse.json({error:"Missing Stripe signature"},{status:400});try{o=s.webhooks.constructEvent(n,i,r)}catch(e){return console.error("Webhook signature verification failed:",e?.message),a.NextResponse.json({error:"Invalid signature"},{status:400})}if("checkout.session.completed"===o.type){let e=o.data.object;try{let o=await s.checkout.sessions.retrieve(e.id,{expand:["line_items","customer"]}),t=o.metadata||{},r=(t.addons?String(t.addons):"").split(",").map(e=>e.trim()).filter(Boolean),n={customerName:String(t.customerName||"Unknown"),customerEmail:String(o.customer_email||t.customerEmail||"unknown@example.com"),phone:String(t.phone||""),address:String(t.address||""),date:String(t.date||""),time:String(t.time||""),serviceName:String(t.service||o?.line_items?.data?.[0]?.description||"Cleaning Service"),addons:r,totalAmountCents:"number"==typeof o.amount_total?o.amount_total:void 0,currency:o.currency||void 0,sessionId:o.id},i=[{name:"Contractor 1",email:"services@tidymate.ca",phone:"(416) 555-0001",specialties:["airbnb","residential"]},{name:"Contractor 2",email:"services@tidymate.ca",phone:"(416) 555-0002",specialties:["post-construction","commercial"]},{name:"Contractor 3",email:"services@tidymate.ca",phone:"(416) 555-0003",specialties:["airbnb","residential"]},{name:"Contractor 4",email:"services@tidymate.ca",phone:"(416) 555-0004",specialties:["post-construction"]}],a=i[0];a=n.serviceName.toLowerCase().includes("post-construction")?i.find(e=>e.specialties.includes("post-construction"))||i[1]:i.find(e=>e.specialties.includes("airbnb")||e.specialties.includes("residential"))||i[0],console.log(`✅ Contractor assigned: ${a.name} (${a.email})`);let d={contractorName:a.name,contractorEmail:a.email,contractorPhone:a.phone,estimatedDuration:3};await (0,c.bd)(n,d),n.customerEmail&&"unknown@example.com"!==n.customerEmail&&await (0,c.d2)(n,n.customerEmail),await (0,c.EA)(a.email,a.name,{service:n.serviceName,addons:n.addons.join(", "),estimatedDuration:"3 hours",date:n.date,time:n.time,address:n.address,instructions:t.instructions||"",customerName:n.customerName,phone:n.phone,customerEmail:n.customerEmail}),await addBookingToSheet({timestamp:new Date().toISOString(),customerName:n.customerName,customerEmail:n.customerEmail,phone:n.phone,address:n.address,service:n.serviceName,addons:n.addons.join(", "),totalAmount:n.totalAmountCents?`$${(n.totalAmountCents/100).toFixed(2)} ${n.currency?.toUpperCase()||"CAD"}`:"Unknown",date:n.date,time:n.time,instructions:t.instructions||"",sessionId:n.sessionId||"",paymentStatus:"Completed",contractorName:a.name,contractorEmail:a.email,contractorPhone:a.phone,estimatedDuration:"3 hours"}),m(n),console.log("✅ Booking processed and emails sent to all parties"),console.log(`✅ REAL contractor assigned from your sheet: ${a.name} (${a.email})`)}catch(e){console.error("Error handling checkout.session.completed:",e)}}return a.NextResponse.json({received:!0})}let u=new s.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/stripe/webhook/route",pathname:"/api/stripe/webhook",filename:"route",bundlePath:"app/api/stripe/webhook/route"},resolvedPagePath:"/workspace/fix-404/app/api/stripe/webhook/route.ts",nextConfigOutput:"",userland:r}),{requestAsyncStorage:h,staticGenerationAsyncStorage:f,serverHooks:y}=u,b="/api/stripe/webhook/route";function v(){return(0,i.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:f})}},7077:(e,o,t)=>{t.d(o,{EA:()=>l,bd:()=>a,d2:()=>c,rJ:()=>d});var r=t(54425);let s=process.env.RESEND_API_KEY,n=process.env.OWNER_NOTIFICATION_EMAIL||"services@tidymate.ca",i=process.env.FROM_EMAIL||"noreply@tidymate.ca";async function a(e,o){if(!s)return console.warn("Email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let t=new r.R(s),a=`New Booking: ${e.serviceName} for ${e.customerName}${o?` - Assigned to ${o.contractorName}`:""}`,d=e.addons&&e.addons.length>0?e.addons.join(", "):"None",c=e.totalAmountCents&&e.currency?`${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`:"(total shown in Stripe)",l=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #059669;">💼 New Booking Received - ${o?"Contractor Assigned":"Action Required"}</h2>
			
			${o?`
			<div style="background: #d1fae5; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
				<h3 style="margin-top: 0; color: #065f46;">👷 CONTRACTOR ASSIGNED</h3>
				<p><strong>Assigned to:</strong> ${o.contractorName}</p>
				<p><strong>Contractor Email:</strong> ${o.contractorEmail}</p>
				<p><strong>Contractor Phone:</strong> ${o.contractorPhone}</p>
				<p><strong>Estimated Duration:</strong> ${o.estimatedDuration||"2-3 hours"}</p>
				<p><em>✅ Contractor has been automatically notified via email</em></p>
			</div>
			`:`
			<div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h3>⚠️ MANUAL ASSIGNMENT NEEDED:</h3>
				<p>No contractor was automatically assigned. Please assign manually.</p>
			</div>
			`}
			
			<div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">📋 Booking Details</h3>
				<p><strong>Service:</strong> ${e.serviceName}</p>
				<p><strong>Add-ons:</strong> ${d}</p>
				<p><strong>Total Paid:</strong> ${c}</p>
				<p><strong>Date:</strong> ${e.date}</p>
				<p><strong>Time:</strong> ${e.time}</p>
				${e.sessionId?`<p><strong>Payment Session:</strong> ${e.sessionId}</p>`:""}
			</div>
			
			<div style="background: #fef7cd; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
				<h3 style="margin-top: 0; color: #92400e;">👤 Customer Information</h3>
				<p><strong>Name:</strong> ${e.customerName}</p>
				<p><strong>Email:</strong> ${e.customerEmail}</p>
				<p><strong>Phone:</strong> ${e.phone}</p>
				<p><strong>Address:</strong> ${e.address}</p>
				<p><strong>Special Instructions:</strong> ${e.address}</p>
			</div>
			
			<div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #22c55e;">
				<h3 style="margin-top: 0; color: #15803d;">📋 Your Action Items</h3>
				<ol style="color: #166534;">
					${o?`<li><strong>Contractor notified</strong> - ${o.contractorName} has been emailed</li>
						 <li><strong>Monitor progress</strong> - Follow up with contractor if needed</li>
						 <li><strong>Customer contact</strong> - Confirm final scheduling with customer</li>`:`<li><strong>Assign contractor manually</strong> - No automatic assignment made</li>
						 <li><strong>Contact customer</strong> - Confirm scheduling details</li>
						 <li><strong>Send contractor details</strong> - Once assigned</li>`}
					<li><strong>Quality check</strong> - Ensure service meets TidyMate standards</li>
				</ol>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>📊 Booking tracked in Google Sheets</strong><br/>
				All details automatically recorded for your records
			</p>
		</div>
	`;return await t.emails.send({from:i,to:n,subject:a,html:l}),{success:!0}}async function d(e){if(!s)return console.error("❌ RESEND_API_KEY is not configured"),{skipped:!0,error:"RESEND_API_KEY not configured"};let o=new r.R(s),t=process.env.CONTACT_TO_EMAIL||"services@tidymate.ca",n=`[Contact] ${e.subject||"New message"} — ${e.name}`;console.log("\uD83D\uDCE7 Attempting to send email:",{from:i,to:t,subject:n,hasApiKey:!!s});let a=`
		<h2>New Contact Form Submission</h2>
		<p><strong>Name:</strong> ${e.name}</p>
		<p><strong>Email:</strong> ${e.email}</p>
		<p><strong>Subject:</strong> ${e.subject}</p>
		<p><strong>Message:</strong><br/>${e.message.replace(/\n/g,"<br/>")}</p>
	`;try{let e=await o.emails.send({from:i,to:t,subject:n,html:a});return console.log("✅ Email sent successfully:",e),{success:!0,result:e}}catch(e){throw console.error("❌ Email send failed:",e),Error(`Email send failed: ${e.message}`)}}async function c(e,o){if(!s)return console.warn("Customer email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let t=new r.R(s),n=`Your TidyMate Booking is Confirmed - ${e.serviceName}`,a=e.addons&&e.addons.length>0?e.addons.join(", "):"None",d=e.totalAmountCents&&e.currency?`${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`:"(total shown in receipt)",c=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #2563eb;">🎉 Booking Confirmed - Thank you, ${e.customerName}!</h2>
			<p>Your cleaning service has been booked and payment processed successfully!</p>
			
			<div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">📋 Your Booking Details</h3>
				<p><strong>Service:</strong> ${e.serviceName}</p>
				<p><strong>Add-ons:</strong> ${a}</p>
				<p><strong>Total Paid:</strong> ${d}</p>
				<p><strong>Requested Date:</strong> ${e.date}</p>
				<p><strong>Preferred Time:</strong> ${e.time}</p>
				<p><strong>Service Address:</strong> ${e.address}</p>
				${e.sessionId?`<p><strong>Booking Reference:</strong> ${e.sessionId}</p>`:""}
			</div>
			
			<div style="background: #f0f9ff; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h3 style="color: #1e40af;">📅 What Happens Next:</h3>
				<ol style="color: #374151;">
					<li><strong>We'll contact you within 2 hours</strong> to confirm the exact time slot</li>
					<li><strong>Our professional cleaner will arrive</strong> at your scheduled time</li>
					<li><strong>Enjoy your spotless space!</strong></li>
				</ol>
			</div>
			
			<div style="background: #ecfdf5; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #10b981;">
				<h4 style="margin-top: 0; color: #065f46;">🔒 Payment Confirmation</h4>
				<p style="color: #047857;">✅ Your payment has been securely processed</p>
				<p style="color: #047857;">✅ Booking is confirmed and scheduled</p>
			</div>
			
			<div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 15px 0;">
				<h4 style="margin-top: 0; color: #92400e;">📞 Important Reminders</h4>
				<ul style="color: #78350f;">
					<li><strong>Cancellation Policy:</strong> No refunds after booking. Cancellations within 24 hours result in payment forfeiture.</li>
					<li><strong>Access:</strong> Please ensure someone is available to provide access to the property</li>
					<li><strong>Contact:</strong> Call or email us immediately if you need to make changes</li>
				</ul>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>Questions or concerns?</strong><br/>
				Email: <a href="mailto:services@tidymate.ca" style="color: #2563eb;">services@tidymate.ca</a><br/>
				We're here to help ensure your cleaning experience is perfect!
			</p>
		</div>
	`;return await t.emails.send({from:i,to:o,subject:n,html:c}),{success:!0}}async function l(e,o,t){if(!s)return console.warn("Contractor email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let n=new r.R(s),a=`New Job Assignment - ${t.service} on ${t.date}`,d=`
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2 style="color: #dc2626;">🔧 New Job Assignment - ${o}</h2>
			<p>You have been assigned a new cleaning job. Please review the details below:</p>
			
			<div style="background: #fee2e2; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #dc2626;">
				<h3 style="margin-top: 0; color: #991b1b;">📋 Job Details</h3>
				<p><strong>Service:</strong> ${t.service}</p>
				<p><strong>Add-ons:</strong> ${t.addons||"None"}</p>
				<p><strong>Estimated Duration:</strong> ${t.estimatedDuration||"2-3 hours"}</p>
				<p><strong>Date:</strong> ${t.date}</p>
				<p><strong>Time:</strong> ${t.time}</p>
			</div>
			
			<div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
				<h3 style="margin-top: 0; color: #92400e;">📍 Location & Access</h3>
				<p><strong>Address:</strong> ${t.address}</p>
				<p><strong>Special Instructions:</strong> ${t.instructions||"None provided"}</p>
			</div>
			
			<div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
				<h3 style="margin-top: 0; color: #1d4ed8;">👤 Customer Information</h3>
				<p><strong>Customer:</strong> ${t.customerName}</p>
				<p><strong>Phone:</strong> ${t.phone}</p>
				<p><strong>Email:</strong> ${t.customerEmail}</p>
			</div>
			
			<div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #22c55e;">
				<h3 style="margin-top: 0; color: #15803d;">✅ Action Required</h3>
				<ol style="color: #166534;">
					<li><strong>Contact customer</strong> to confirm exact arrival time</li>
					<li><strong>Arrive punctually</strong> with all necessary equipment</li>
					<li><strong>Complete service</strong> according to TidyMate standards</li>
					<li><strong>Send completion confirmation</strong> to services@tidymate.ca</li>
				</ol>
			</div>
			
			<hr style="margin: 30px 0; border: 1px solid #e5e7eb;"/>
			<p style="text-align: center; color: #6b7280;">
				<strong>Questions about this assignment?</strong><br/>
				Contact: <a href="mailto:services@tidymate.ca" style="color: #2563eb;">services@tidymate.ca</a><br/>
				<strong>Payment:</strong> You'll be paid according to your contractor agreement
			</p>
		</div>
	`;return await n.emails.send({from:i,to:e,subject:a,html:d}),{success:!0}}}};var o=require("../../../../webpack-runtime.js");o.C(e);var t=e=>o(o.s=e),r=o.X(0,[379,833,425,854],()=>t(98922));module.exports=r})();