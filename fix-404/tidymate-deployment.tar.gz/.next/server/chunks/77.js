"use strict";exports.id=77,exports.ids=[77],exports.modules={7077:(e,t,r)=>{r.d(t,{bd:()=>a,d2:()=>d,rJ:()=>l});var n=r(4425);let s=process.env.RESEND_API_KEY,i=process.env.OWNER_NOTIFICATION_EMAIL||"services@tidymate.ca",o=process.env.FROM_EMAIL||"noreply@tidymate.ca";async function a(e){if(!s)return console.warn("Email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let t=new n.R(s),r=`New Booking: ${e.serviceName} for ${e.customerName}`,a=e.addons&&e.addons.length>0?e.addons.join(", "):"None",l=e.totalAmountCents&&e.currency?`${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`:"(total shown in Stripe)",d=`
		<h2>🎉 New Booking Received - Action Required</h2>
		<div style="background: #f0f9ff; padding: 15px; border-radius: 8px; margin: 15px 0;">
			<h3>📅 CALENDLY ACTION NEEDED:</h3>
			<p><strong>Send this link to customer to confirm their exact time slot:</strong></p>
			<p><a href="https://calendly.com/services-tidymate/booking-confirmation" style="background: #0066cc; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Customer Calendly Booking Link</a></p>
			<p><em>Send this link to customer via email or text</em></p>
		</div>
		
		<h3>Booking Details:</h3>
		<p><strong>Service:</strong> ${e.serviceName}</p>
		<p><strong>Add-ons:</strong> ${a}</p>
		<p><strong>Total Paid:</strong> ${l}</p>
		${e.sessionId?`<p><strong>Payment Session:</strong> ${e.sessionId}</p>`:""}
		
		<h3>Customer Information:</h3>
		<p><strong>Name:</strong> ${e.customerName}</p>
		<p><strong>Email:</strong> ${e.customerEmail}</p>
		<p><strong>Phone:</strong> ${e.phone}</p>
		<p><strong>Address:</strong> ${e.address}</p>
		<p><strong>Requested Date & Time:</strong> ${e.date} at ${e.time}</p>
		
		<hr style="margin: 20px 0;"/>
		<h3>📋 Your Action Items:</h3>
		<ol>
			<li><strong>Send Calendly link above to customer</strong> - They'll pick exact time slot</li>
			<li><strong>You'll get Calendly notification</strong> when they book</li>
			<li><strong>Confirm service availability</strong> and send final details</li>
		</ol>
		
		<div style="background: #f0f9ff; padding: 10px; border-radius: 5px; margin-top: 15px;">
			<p><strong>💡 Pro Tip:</strong> All customer bookings through Calendly will automatically appear in your calendar at calendly.com/services-tidymate!</p>
		</div>
	`;return await t.emails.send({from:o,to:i,subject:r,html:d}),{success:!0}}async function l(e){if(!s)return console.error("❌ RESEND_API_KEY is not configured"),{skipped:!0,error:"RESEND_API_KEY not configured"};let t=new n.R(s),r=process.env.CONTACT_TO_EMAIL||"services@tidymate.ca",i=`[Contact] ${e.subject||"New message"} — ${e.name}`;console.log("\uD83D\uDCE7 Attempting to send email:",{from:o,to:r,subject:i,hasApiKey:!!s});let a=`
		<h2>New Contact Form Submission</h2>
		<p><strong>Name:</strong> ${e.name}</p>
		<p><strong>Email:</strong> ${e.email}</p>
		<p><strong>Subject:</strong> ${e.subject}</p>
		<p><strong>Message:</strong><br/>${e.message.replace(/\n/g,"<br/>")}</p>
	`;try{let e=await t.emails.send({from:o,to:r,subject:i,html:a});return console.log("✅ Email sent successfully:",e),{success:!0,result:e}}catch(e){throw console.error("❌ Email send failed:",e),Error(`Email send failed: ${e.message}`)}}async function d(e,t){if(!s)return console.warn("Customer email not sent: RESEND_API_KEY is not configured."),{skipped:!0};let r=new n.R(s),i=e.addons&&e.addons.length>0?e.addons.join(", "):"None",a=e.totalAmountCents&&e.currency?`${(e.totalAmountCents/100).toFixed(2)} ${e.currency.toUpperCase()}`:"(total shown in receipt)",l=`
		<h2>🎉 Thank you, ${e.customerName}!</h2>
		<p>Your booking is confirmed and payment has been processed successfully!</p>
		
		<div style="background: #f0f9ff; padding: 15px; border-radius: 8px; margin: 15px 0;">
			<h3>📅 Next Step: Choose Your Exact Time Slot</h3>
			<p>You'll receive a <strong>Calendly booking link</strong> from us within 2 hours to select your preferred time slot.</p>
		</div>
		
		<h3>Your Booking Details:</h3>
		<p><strong>Service:</strong> ${e.serviceName}</p>
		<p><strong>Add-ons:</strong> ${i}</p>
		<p><strong>Total Paid:</strong> ${a}</p>
		${e.sessionId?`<p><strong>Reference ID:</strong> ${e.sessionId}</p>`:""}
		
		<p><strong>Requested Date & Time:</strong> ${e.date} at ${e.time}</p>
		
		<hr style="margin: 20px 0;"/>
		<h3>📋 What Happens Next:</h3>
		<ol>
			<li><strong>We'll send you a Calendly link</strong> to pick your exact time slot</li>
			<li><strong>Book your preferred time</strong> through Calendly</li>
			<li><strong>Receive final confirmation</strong> with cleaner details</li>
			<li><strong>Enjoy your professional cleaning!</strong></li>
		</ol>
		
		<div style="background: #e6f7e6; padding: 10px; border-radius: 5px; margin-top: 15px;">
			<p><strong>✅ Your payment is secure and confirmed!</strong></p>
			<p>We look forward to providing you with exceptional cleaning service!</p>
		</div>
		
		<p style="margin-top: 20px;"><em>Questions? Reply to this email or contact us at services@tidymate.ca</em></p>
	`;return await r.emails.send({from:o,to:t,subject:"Your TidyMate Booking is Confirmed",html:l}),{success:!0}}},4425:(e,t,r)=>{r.d(t,{R:()=>k});var n=Object.defineProperty,s=Object.defineProperties,i=Object.getOwnPropertyDescriptors,o=Object.getOwnPropertySymbols,a=Object.prototype.hasOwnProperty,l=Object.prototype.propertyIsEnumerable,d=(e,t,r)=>t in e?n(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,c=(e,t)=>{for(var r in t||(t={}))a.call(t,r)&&d(e,r,t[r]);if(o)for(var r of o(t))l.call(t,r)&&d(e,r,t[r]);return e},u=(e,t)=>s(e,i(t)),h=(e,t,r)=>new Promise((n,s)=>{var i=e=>{try{a(r.next(e))}catch(e){s(e)}},o=e=>{try{a(r.throw(e))}catch(e){s(e)}},a=e=>e.done?n(e.value):Promise.resolve(e.value).then(i,o);a((r=r.apply(e,t)).next())}),p=class{constructor(e){this.resend=e}create(e){return h(this,arguments,function*(e,t={}){return yield this.resend.post("/api-keys",e,t)})}list(){return h(this,null,function*(){return yield this.resend.get("/api-keys")})}remove(e){return h(this,null,function*(){return yield this.resend.delete(`/api-keys/${e}`)})}},m=class{constructor(e){this.resend=e}create(e){return h(this,arguments,function*(e,t={}){return yield this.resend.post("/audiences",e,t)})}list(){return h(this,null,function*(){return yield this.resend.get("/audiences")})}get(e){return h(this,null,function*(){return yield this.resend.get(`/audiences/${e}`)})}remove(e){return h(this,null,function*(){return yield this.resend.delete(`/audiences/${e}`)})}};function y(e){var t;return{attachments:null==(t=e.attachments)?void 0:t.map(e=>({content:e.content,filename:e.filename,path:e.path,content_type:e.contentType,content_id:e.contentId})),bcc:e.bcc,cc:e.cc,from:e.from,headers:e.headers,html:e.html,reply_to:e.replyTo,scheduled_at:e.scheduledAt,subject:e.subject,tags:e.tags,text:e.text,to:e.to}}var g=class{constructor(e){this.resend=e}send(e){return h(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return h(this,arguments,function*(e,t={}){let n=[];for(let t of e){if(t.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(486).then(r.t.bind(r,5486,19));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}t.html=yield this.renderAsync(t.react),t.react=void 0}n.push(y(t))}return yield this.resend.post("/emails/batch",n,t)})}},f=class{constructor(e){this.resend=e}create(e){return h(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(486).then(r.t.bind(r,5486,19));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/broadcasts",{name:e.name,audience_id:e.audienceId,preview_text:e.previewText,from:e.from,html:e.html,reply_to:e.replyTo,subject:e.subject,text:e.text},t)})}send(e,t){return h(this,null,function*(){return yield this.resend.post(`/broadcasts/${e}/send`,{scheduled_at:null==t?void 0:t.scheduledAt})})}list(){return h(this,null,function*(){return yield this.resend.get("/broadcasts")})}get(e){return h(this,null,function*(){return yield this.resend.get(`/broadcasts/${e}`)})}remove(e){return h(this,null,function*(){return yield this.resend.delete(`/broadcasts/${e}`)})}update(e,t){return h(this,null,function*(){return yield this.resend.patch(`/broadcasts/${e}`,{name:t.name,audience_id:t.audienceId,from:t.from,html:t.html,text:t.text,subject:t.subject,reply_to:t.replyTo,preview_text:t.previewText})})}},b=class{constructor(e){this.resend=e}create(e){return h(this,arguments,function*(e,t={}){return yield this.resend.post(`/audiences/${e.audienceId}/contacts`,{unsubscribed:e.unsubscribed,email:e.email,first_name:e.firstName,last_name:e.lastName},t)})}list(e){return h(this,null,function*(){return yield this.resend.get(`/audiences/${e.audienceId}/contacts`)})}get(e){return h(this,null,function*(){return e.id||e.email?yield this.resend.get(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}update(e){return h(this,null,function*(){return e.id||e.email?yield this.resend.patch(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`,{unsubscribed:e.unsubscribed,first_name:e.firstName,last_name:e.lastName}):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}remove(e){return h(this,null,function*(){return e.id||e.email?yield this.resend.delete(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}},v=class{constructor(e){this.resend=e}create(e){return h(this,arguments,function*(e,t={}){return yield this.resend.post("/domains",{name:e.name,region:e.region,custom_return_path:e.customReturnPath},t)})}list(){return h(this,null,function*(){return yield this.resend.get("/domains")})}get(e){return h(this,null,function*(){return yield this.resend.get(`/domains/${e}`)})}update(e){return h(this,null,function*(){return yield this.resend.patch(`/domains/${e.id}`,{click_tracking:e.clickTracking,open_tracking:e.openTracking,tls:e.tls})})}remove(e){return h(this,null,function*(){return yield this.resend.delete(`/domains/${e}`)})}verify(e){return h(this,null,function*(){return yield this.resend.post(`/domains/${e}/verify`)})}},$=class{constructor(e){this.resend=e}send(e){return h(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return h(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(486).then(r.t.bind(r,5486,19));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/emails",y(e),t)})}get(e){return h(this,null,function*(){return yield this.resend.get(`/emails/${e}`)})}update(e){return h(this,null,function*(){return yield this.resend.patch(`/emails/${e.id}`,{scheduled_at:e.scheduledAt})})}cancel(e){return h(this,null,function*(){return yield this.resend.post(`/emails/${e}/cancel`)})}},E="undefined"!=typeof process&&process.env&&process.env.RESEND_BASE_URL||"https://api.resend.com",_="undefined"!=typeof process&&process.env&&process.env.RESEND_USER_AGENT||"resend-node:6.0.3",k=class{constructor(e){if(this.key=e,this.apiKeys=new p(this),this.audiences=new m(this),this.batch=new g(this),this.broadcasts=new f(this),this.contacts=new b(this),this.domains=new v(this),this.emails=new $(this),!e&&("undefined"!=typeof process&&process.env&&(this.key=process.env.RESEND_API_KEY),!this.key))throw Error('Missing API key. Pass it to the constructor `new Resend("re_123")`');this.headers=new Headers({Authorization:`Bearer ${this.key}`,"User-Agent":_,"Content-Type":"application/json"})}fetchRequest(e){return h(this,arguments,function*(e,t={}){try{let r=yield fetch(`${E}${e}`,t);if(!r.ok)try{let e=yield r.text();return{data:null,error:JSON.parse(e)}}catch(t){if(t instanceof SyntaxError)return{data:null,error:{name:"application_error",message:"Internal server error. We are unable to process your request right now, please try again later."}};let e={message:r.statusText,name:"application_error"};if(t instanceof Error)return{data:null,error:u(c({},e),{message:t.message})};return{data:null,error:e}}return{data:yield r.json(),error:null}}catch(e){return{data:null,error:{name:"application_error",message:"Unable to fetch data. The request could not be resolved."}}}})}post(e,t){return h(this,arguments,function*(e,t,r={}){let n=new Headers(this.headers);r.idempotencyKey&&n.set("Idempotency-Key",r.idempotencyKey);let s=c({method:"POST",headers:n,body:JSON.stringify(t)},r);return this.fetchRequest(e,s)})}get(e){return h(this,arguments,function*(e,t={}){let r=c({method:"GET",headers:this.headers},t);return this.fetchRequest(e,r)})}put(e,t){return h(this,arguments,function*(e,t,r={}){let n=c({method:"PUT",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,n)})}patch(e,t){return h(this,arguments,function*(e,t,r={}){let n=c({method:"PATCH",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,n)})}delete(e,t){return h(this,null,function*(){let r={method:"DELETE",headers:this.headers,body:JSON.stringify(t)};return this.fetchRequest(e,r)})}}}};